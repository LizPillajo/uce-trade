package UCE_Trade.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UceTradeApplicationTests {

	@Test
	void contextLoads() {
	}

}
